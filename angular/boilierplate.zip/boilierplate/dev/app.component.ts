import {Component} from 'angular2/core';
import {contactList} from "./contacts/contactList.component";

@Component({
    selector: 'my-app',
    template: `
        <contact-list></contact-list>
    `,
    directives: [contactList]
})
export class AppComponent {
}
