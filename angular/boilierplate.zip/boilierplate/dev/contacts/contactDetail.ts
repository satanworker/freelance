/**
 * Created by mini on 30.03.16.
 */
import {Component} from 'angular2/core';
import {AppComponent} from "../app.component";


@Component({
    selector: 'contact-detail',
    template: `
    <input type="text" [(ngModel)] = "contact.name" value="" placeholder="{{contact.tel}}"/>
        <div *ngIf="contact">
            {{contact.email}} {{contact.tel}}
        </div>
    `,
    inputs: ["contact"],
    styleUrls: ["../src/css/contact_list.css"]
})

export class contactDetail {

}