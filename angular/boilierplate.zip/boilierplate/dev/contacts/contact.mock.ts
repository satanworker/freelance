/**
 * Created by mini on 30.03.16.
 */
import {Contact} from "./contact";
export const CONTACTS: Contact[] = [
    {
        name: 'Dima',
        surname: 'Petrov',
        tel: '98095890',
        email: 'ssss@ss.com'
    },
    {
        name: 'Max',
        surname: 'Sergeev',
        tel: '98095890',
        email: 'ssss@ss.com'
    },
];