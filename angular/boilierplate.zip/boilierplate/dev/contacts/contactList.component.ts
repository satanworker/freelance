/**
 * Created by mini on 30.03.16.
 */
import {Component} from 'angular2/core';
import {AppComponent} from "../app.component";
import {contactDetail} from "./contactDetail";
import {ContactService} from "./contact.service";
import {Contact} from "./contact"
import {OnInit} from "angular2/core";


@Component({
    selector: 'contact-list',
    template: `
        <ul>
            <li *ngFor="#contact of contacts">
                <h1 (click)="onSelect(contact)"  [class.red] = "selectedContact == contact">{{contact.name}} {{contact.surname}}</h1>
            </li>
        </ul>
        <contact-detail [contact]="selectedContact"></contact-detail>
        <span (click)="startPromise()">Start timeout</span>
    `,
    styleUrls:['../src/css/app.css'],
    directives: [contactDetail],
    providers: [ContactService]
})

export class contactList implements OnInit {
    //initializing of contacts from service
    public contacts: Contact[];

    constructor(private _contactService: ContactService) {}

    getContacts() {
        this._contactService.getContacts().then((contacts: Contact[]) => { this.contacts = contacts; this.selectedContact = this.contacts[0]; })
    }
    //>> end of initializing

    public selectedContact = {};
    onSelect(contact) {
        this.selectedContact = contact;
    }
    ngOnInit():any  {
        this.getContacts();
    }
}