/**
 * Created by mini on 30.03.16.
 */

import {Injectable} from 'angular2/core';
import {CONTACTS} from "./contact.mock";

@Injectable()
export class ContactService {
    getContacts() {
        return Promise.resolve(CONTACTS)
    }
}