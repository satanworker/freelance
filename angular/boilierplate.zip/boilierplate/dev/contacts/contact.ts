/**
 * Created by mini on 30.03.16.
 */
export interface Contact {
    name: string,
    tel: string
    surname: string,
    email: string
}