System.register([], function(exports_1) {
    var CONTACTS;
    return {
        setters:[],
        execute: function() {
            exports_1("CONTACTS", CONTACTS = [
                {
                    name: 'Dima',
                    surname: 'Petrov',
                    tel: '98095890',
                    email: 'ssss@ss.com'
                },
                {
                    name: 'Max',
                    surname: 'Sergeev',
                    tel: '98095890',
                    email: 'ssss@ss.com'
                },
            ]);
        }
    }
});
//# sourceMappingURL=contact.mock.js.map