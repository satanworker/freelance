<a name="0.1.11"></a>
# 0.1.11 (2016-03-18)
* update packages
  * Angular 2 beta 11
  * zones 0.6.4
  * typescript 1.8.9
  * typings 0.7.9